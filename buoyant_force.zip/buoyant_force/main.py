#libs
from pygame.locals import *
import pygame
import random
import sys
from  fluid import Pseudo_Fluid
from object import BuoyantObject

# constants
g = 0.5
speed_capyd = -3
speed_capyu = 50

pygame.init()
clock = pygame.time.Clock()

fps = 50
BG = 'lightgrey'
DIMENSIONS = (1200, 600)
WIN = pygame.display.set_mode(DIMENSIONS)
pygame.display.set_caption('Gravity')

obj_group = [BuoyantObject(WIN,100, 10,g,speed_capyd,speed_capyu,density=10)]
pseudo_water = Pseudo_Fluid(WIN,0, 400,g,obj_group,density=500)

if __name__ == '__main__':
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()
            if event.type == MOUSEBUTTONDOWN:
                #adding objects by right-clicking
                if event.button == 3:
                    density = random.randint(10, 600)
                    x_vel = random.randint(-20,20)
                    new_object = BuoyantObject(WIN,*pygame.mouse.get_pos(),g,speed_capyd,speed_capyu,
                                               density=density)
                    new_object.x_vel=x_vel
                    obj_group.append(new_object)
                #removing objects by middle-clicking
                if event.button == 2:
                    mods = pygame.key.get_mods()
                    if mods & KMOD_CTRL: obj_group.clear()
                    else:
                        for buo_obj in obj_group:
                            if buo_obj.rect.collidepoint(pygame.mouse.get_pos()):
                                obj_group.remove(buo_obj)
                 #dragging it
                if event.button == 1:
                    for buo_obj in obj_group:
                        if buo_obj.rect.collidepoint(pygame.mouse.get_pos()):
                            buo_obj.dragging = True
                            buo_obj.drag_offset = (pygame.mouse.get_pos()[0] - buo_obj.x,
                                                   pygame.mouse.get_pos()[1] - buo_obj.y)
                            buo_obj.mouse_traj.clear()
            if event.type == MOUSEBUTTONUP:
                if event.button == 1:
                    for buo_obj in obj_group:
                        buo_obj.dragging = False

        WIN.fill(BG)  # backround
        pseudo_water.update()
        for buo_obj in obj_group:
            buo_obj.update()

        pygame.display.update()
        clock.tick(fps)

import pygame

class BuoyantObject:
    def __init__(self, scr, x, y, g,speed_capyd,speed_capyu,e=0.78, mass=None, size=(20, 20),density=None,
                 color='red',border_color='black',border_width=1,shape='ellipse'):
        self.x = x  # positon
        self.y = y
        self.y_vel = 0  # velocty
        self.x_vel = 0

        self.g = g  # gravitaional acceleration
        self.speed_capyd = speed_capyd
        self.speed_capyu = speed_capyu
        self.e = e  # elasticity coefficient
        self.mass = mass  # mass
        self.size = size  # size
        self.volume = self.size[0] * self.size[1]  # considering breadth is 1m
        self.p = density  # density
        #setting everyhting if only one value is given
        if not self.p and self.mass:self.p = self.mass / self.volume
        elif not self.mass and self.p: self.mass = self.volume*self.p
        else: raise ValueError("At least Mass or Density needs to be given.")
        self.weight = self.mass * self.g  # wight

        #gui and other parts
        self.in_liquid = False  # checks if it is in liquid
        self.show_text = False
        self.dragging = False
        self.mouse_traj = []
        self.drag_offset = (0,0)

        # other attributes
        self.scr = scr #main display
        self.color = color #color
        self.border_color = border_color #bd color
        self.border = border_width #bd width
        self.shape = shape #hspae i.e circle or rectangle
        self.font = pygame.font.Font(None, 32) #font
        self.rect = pygame.Rect(self.x, self.y, self.size[0], self.size[1]) #rectangle

    def apply_motion(self):
        #ensuring it doesnt appply gravity twice
        if not self.dragging:
            if not self.in_liquid:
                self.y_vel += self.g
            if self.y_vel < self.speed_capyd:
                self.y_vel = self.speed_capyd
            if self.y_vel > self.speed_capyu:
                self.y_vel = self.speed_capyu
            self.y += self.y_vel
            self.x += self.x_vel/10
        else:
            try:
                mx, my = pygame.mouse.get_pos()
                self.x = mx - self.drag_offset[0]
                self.y = my - self.drag_offset[1]
                self.x_vel = self.mouse_traj[-1][0] - self.mouse_traj[0][0]
                self.y_vel = self.mouse_traj[-1][1] - self.mouse_traj[0][1]
            except IndexError:
                pass

        # ensire it doesnt go off the floor
        if self.y >= self.scr.get_height() - self.size[1]:
            self.y = self.scr.get_height() - self.size[1]
            if not self.in_liquid:
                self.y_vel *= -self.e
                self.x_vel *= self.e
            else:
                self.y_vel = 0
                self.x_vel = 0
        #ensure it doesn't go out of the walls
        if self.x<=0:
            self.x=0
            self.x_vel*=-self.e
        if self.x >= self.scr.get_width()-self.size[0]:
            self.x = self.scr.get_width()-self.size[0]
            self.x_vel *= -self.e

        #ip[dating evryhting
        self.rect.topleft = (self.x, self.y)

    def draw(self):
        #drawing a selected shape
        if self.shape == 'ellipse':
            pygame.draw.ellipse(self.scr, self.color, self.rect)
            pygame.draw.ellipse(self.scr, self.border_color, self.rect, self.border)
        elif self.shape == 'rectangle':
            pygame.draw.rect(self.scr, self.color, self.rect)
            pygame.draw.rect(self.scr, self.border_color, self.rect, self.border)

        #showing stats
        text = f'Mass:{self.mass},P:{self.p}'
        text_surface = self.font.render(str(text), True, (255, 255, 255))
        if self.show_text: self.scr.blit(text_surface, (self.rect.x, self.rect.y - 20))

    def update(self):
        self.draw()
        self.apply_motion()
        if self.rect.collidepoint(pygame.mouse.get_pos()): self.show_text = True
        else: self.show_text = False
        # mouse traj
        self.mouse_traj.append(pygame.mouse.get_pos())
        if len(self.mouse_traj) > 10: self.mouse_traj.pop(0)

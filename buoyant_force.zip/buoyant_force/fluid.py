import pygame

class Pseudo_Fluid:
    def __init__(self, scr, x, y, g, obj_group, size=(1200, 200), mass=None, density=None, k=1.2,
                 color='lightblue'):
        self.x = x
        self.y = y
        self.g = g  # g
        self.k = k  # friction coefficient
        self.mass = mass #mass
        self.size = size #size
        self.volume = self.size[0] * self.size[1]  # considering breadth is 1m
        self.p = density  # density
        if not self.p and self.mass: self.p = self.mass / self.volume
        elif not self.mass and self.p: self.mass = self.volume * self.p
        else: raise ValueError("At least Mass or Density needs to be given.")

        #other attributes
        self.scr = scr #main display
        self.obj_group = obj_group #object groups
        self.color = color #color
        self.rect = pygame.Rect(self.x, self.y, self.size[0], self.size[1]) #rectangle

    def apply_effects(self, objects):
        for obj in objects:
            if self.rect.colliderect(obj.rect):
                obj.in_liquid = True  # checks if it is submerged or not
                submerged_height = max(0, obj.rect.bottom - self.rect.top) #how much depth is it at
                submerged_volume = min(1, submerged_height / obj.size[1]) #how much volume it is submerged
                F_B = self.p * self.g * obj.volume * submerged_volume  # buoyancy force
                F_d = -0.5 * self.k * obj.y_vel * abs(obj.y_vel)  # drag force
                F_net = obj.weight - F_B + F_d  # total force acting on the ball
                a = F_net / obj.mass  # acceleration
                obj.y_vel += a*0.9  # adding the acceleration
                obj.x_vel *= 0.78 #ressist the ball in x direction
            else: obj.in_liquid = False

    def draw(self):
        pygame.draw.rect(self.scr, self.color, self.rect)

    def update(self):
        self.draw()
        self.apply_effects(self.obj_group)